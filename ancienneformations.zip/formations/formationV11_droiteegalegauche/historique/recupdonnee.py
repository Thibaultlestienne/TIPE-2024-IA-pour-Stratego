import csv

# Fonction pour extraire les valeurs des paramètres à partir d'une chaîne de caractères
def extract_values(s):
    return [float(x) for x in s.strip().split(' ') if x and x.strip()]

# Ouverture du fichier "4000_iéme_generation_v10.ia" en mode lecture
with open('4999_iéme_generation_v11.ia', 'r') as file:
    lines = file.readlines()  # Lecture de toutes les lignes du fichier

# Initialisation du tableau pour stocker les paramètres
params_array = []

# Boucle pour parcourir les lignes du fichier
for line in lines:
    # Vérification si la ligne contient des paramètres
    if line.startswith('['):
        # Extraction des valeurs des paramètres à partir de la chaîne de caractères
        line_parts = line.split(':', -1)  # Effectue un "split" à partir du dernier deux-points
        params_values = extract_values(line_parts[-1])  # Applique "extract_values" à la dernière partie de la ligne
        # Ajout des valeurs des paramètres au tableau
        params_array.extend(params_values)

# Réorganisation des paramètres dans un tableau 2D
n_rows = 11
n_cols = 10
params_2d = [params_array[i:i+n_cols] for i in range(0, len(params_array), n_cols)]
params_2d = params_2d[:n_rows]  # On ne garde que les n_rows premières lignes

# Écriture des paramètres dans un fichier CSV
with open('params.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile, delimiter=';')
    # Écriture de l'en-tête
    header = [f'parametre{i+j*10}' for j in range(n_rows) for i in range(n_cols)]
    writer.writerow(header)
    # Écriture des données
    for row in params_2d:
        writer.writerow([format(x, '.4f') for x in row])
